# AI Text Fixer

Upload a social media post, ad, banner, or screenshot, and let AI read the
visible text and check it for spelling, grammar, punctuation, clarity, and
marketing-copy quality before you publish.

## Stack

- **Next.js 14** (App Router) + **TypeScript**
- **Tailwind CSS** for styling
- **Zod** for validating the agent's final structured output
- **The Text Fixer agent** (`lib/agent/`) — a tool-using Claude agent (`claude-sonnet-5`) that reads the image, flags issues one at a time via a `flag_issue` tool call, and finishes by calling a `submit_analysis` tool. See "The agent" below.

## Getting started locally

```bash
npm install
cp .env.local.example .env.local
# then edit .env.local and add your Anthropic API key
npm run dev
```

Open http://localhost:3000.

## Environment variables

| Variable | Required | Description |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | Yes | Server-side only. Used in `lib/agent/run-agent.ts` to call the Claude Messages API. Never exposed to the browser. |

`.env.local` is already listed in `.gitignore` — never commit real API keys.

## The agent

`lib/agent/` implements the Text Fixer agent as an actual multi-step, tool-using loop rather than a single "describe the whole image in one JSON blob" prompt:

- **`lib/agent/tools.ts`** — two tools the agent can call: `flag_issue` (call once per issue, as it's found) and `submit_analysis` (call once, at the end, with the full result).
- **`lib/agent/run-agent.ts`** — the orchestration loop. It sends the image to Claude with those two tools available, executes each tool call the model makes (recording flagged issues locally — there's no external side effect to run), feeds the result back, and repeats until the model calls `submit_analysis` or a turn limit is hit. If the model stalls without calling either tool, the loop nudges it once before giving up.

This means the agent decides for itself how many issues to flag and in what order, rather than being forced to guess a fixed-shape response up front — closer to how a human editor works through a page than a single classification call.

## How it works

1. The user uploads an image on `/analyze` (drag-and-drop, click-to-upload, or the built-in example).
2. The image is sent as `multipart/form-data` to `POST /api/analyze`.
3. The API route validates the file (type + size), converts it to base64, and hands it to `analyzeImageWithAi` in `lib/ai.ts`, which runs the Text Fixer agent (see above).
4. Once the agent submits its analysis, `lib/ai.ts` runs one extra code-side check — flagging (never silently changing) any price, URL, hashtag, or number that appears in the extracted text but seems to have dropped out of the corrected text — then validates the combined result against a Zod schema (`lib/validation.ts`). If that validation fails, or the agent times out or errors, the API returns a clear error — the app never fabricates a result.
5. The frontend renders a results dashboard: overall status, extracted text, flagged issues, a corrected version of the copy, and a marketing-copy review.
6. Each analysis is saved to `localStorage` so it shows up on `/history`. No server-side database or file storage is used yet — see "Adding a database" below.

## Project structure

```
app/
  page.tsx              Landing page
  analyze/page.tsx       Upload + analysis workflow
  history/page.tsx       Local analysis history
  api/analyze/route.ts    Server route that calls the AI provider
components/
  upload-dropzone.tsx, image-preview.tsx, analysis-loader.tsx,
  overall-status.tsx, extracted-text.tsx, issue-card.tsx,
  correction-card.tsx, copy-review.tsx, copy-button.tsx,
  analysis-summary.tsx, analysis-result.tsx, empty-state.tsx,
  error-state.tsx, hero-annotation.tsx, site-nav.tsx, site-footer.tsx
  ui/                    button.tsx, badge.tsx, card.tsx
lib/
  ai.ts                  Runs the agent, adds a code-side dropped-entity check, validates the final result
  agent/
    tools.ts              flag_issue / submit_analysis tool schemas
    run-agent.ts           The tool-use orchestration loop (calls Claude)
  validation.ts           Zod schemas + file validation
  types.ts                Shared TypeScript types
  utils.ts                Formatting + clipboard helpers
  history.ts              localStorage-backed history
  demo.ts                 Fixed data for "Try an example"
public/demo/example.svg   Sample design used by demo mode
```

## Deploying to Vercel

1. Push this project to a GitHub repository.
2. In Vercel, click **New Project** and import the repository.
3. Vercel will detect Next.js automatically — no build settings to change.
4. Under **Environment Variables**, add `ANTHROPIC_API_KEY` with your key.
5. Click **Deploy**.
6. Once deployed, open `/analyze` on your new domain and upload a test image to confirm the API route works in Vercel's serverless environment.

The app doesn't write to the local filesystem and doesn't persist uploaded
images anywhere — every request is processed in memory, which fits Vercel's
serverless model without changes.

## Adding a database later

`lib/history.ts` isolates all history read/write calls behind three functions
(`getHistory`, `saveHistoryEntry`, `clearHistory`). To move history to a real
backend (e.g. Supabase):

1. Add authentication (e.g. Supabase Auth, Clerk, NextAuth).
2. Replace the bodies of those three functions with calls to your database,
   keyed by user ID.
3. No component code needs to change — they only depend on that module's
   exported functions and the `HistoryEntry` type in `lib/types.ts`.

## Rate limiting

`app/api/analyze/route.ts` includes a minimal in-memory rate limiter as a
starting point. It resets whenever a serverless instance recycles, so for
real production traffic swap it for a distributed store such as Upstash
Redis (`@upstash/ratelimit`) — the call site is isolated in one function
(`isRateLimited`) to make that swap straightforward.

## Notes on accuracy

Every result is an AI-generated read of the uploaded image, not a
guarantee. OCR can misread stylized fonts, low-contrast text, or heavily
cropped designs — the UI surfaces the model's own confidence and flags low
confidence explicitly so users know to double check against the original.
