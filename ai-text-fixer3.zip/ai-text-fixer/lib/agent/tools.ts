/**
 * Tool definitions the Text Fixer agent can call, in Anthropic Messages
 * API tool-use format. The agent doesn't have "real world" tools (no
 * filesystem, no browser) — its tools are how it reports its own work
 * back to us step by step, instead of guessing at one big JSON blob in
 * a single shot. That's what makes this an agent rather than a prompt:
 * it decides how many issues to flag, flags them one at a time as it
 * finds them, and only calls submit_analysis when it's satisfied its
 * corrected text is safe to hand back.
 */

export const FLAG_ISSUE_TOOL = {
  name: "flag_issue",
  description:
    "Record one specific text issue you've found in the design so far. Call this once per issue, as you find it — do not wait and batch several issues into one call. Skip this tool entirely if the text has no issues.",
  input_schema: {
    type: "object" as const,
    properties: {
      type: {
        type: "string",
        enum: [
          "spelling",
          "grammar",
          "punctuation",
          "capitalization",
          "wording",
          "structure",
          "clarity",
          "duplication",
          "cta",
          "other",
        ],
        description: "The category of issue.",
      },
      severity: {
        type: "string",
        enum: ["critical", "high", "medium", "low"],
        description:
          "How serious this issue is. Use 'low' for optional stylistic improvements, not definite errors.",
      },
      original: {
        type: "string",
        description: "The exact snippet from the extracted text that has the issue.",
      },
      correction: {
        type: "string",
        description: "Your suggested fix for that exact snippet.",
      },
      explanation: {
        type: "string",
        description: "One or two plain-English sentences on why this is an issue.",
      },
    },
    required: ["type", "severity", "original", "correction", "explanation"],
  },
};

export const SUBMIT_ANALYSIS_TOOL = {
  name: "submit_analysis",
  description:
    "Submit your final, finished analysis. Only call this once, after you've read all the visible text and flagged every issue with flag_issue. Before calling this, double-check your correctedText: it must preserve the original meaning and must not alter brand names, product names, URLs, phone numbers, prices, dates, hashtags, or industry terms unless they contain an obvious typo. Calling this tool ends the analysis.",
  input_schema: {
    type: "object" as const,
    properties: {
      overallStatus: {
        type: "string",
        enum: ["correct", "needs_improvement", "incorrect"],
        description:
          "'correct' if grammatically and linguistically acceptable, 'needs_improvement' if understandable but improvable, 'incorrect' if there are clear errors.",
      },
      confidence: {
        type: "number",
        description: "0 to 1 — how confident you are in this whole assessment.",
      },
      qualityScore: {
        type: "number",
        description: "0 to 100 — overall text quality combining correctness and marketing effectiveness.",
      },
      ocrConfidence: {
        type: "number",
        description: "0 to 1 — how confident you are that you read the visible text correctly.",
      },
      extractedText: {
        type: "string",
        description: "The full text you read from the image, verbatim. Empty string if none was readable.",
      },
      hasReadableText: {
        type: "boolean",
        description: "False if no readable text was present anywhere in the image.",
      },
      correctedText: {
        type: "string",
        description: "The full corrected version of extractedText, meaning and brand details preserved.",
      },
      copyReview: {
        type: "object",
        properties: {
          hook: { type: "string" },
          clarity: { type: "string" },
          valueProposition: { type: "string" },
          cta: { type: "string" },
          readability: { type: "string" },
          conciseness: { type: "string" },
          tone: { type: "string" },
          overall: { type: "string" },
        },
        required: ["hook", "clarity", "valueProposition", "cta", "readability", "conciseness", "tone", "overall"],
        description: "Short, specific sentences for each — not single-word scores.",
      },
      notes: {
        type: "string",
        description: "Optional — flag anything unreadable, cropped, or ambiguous here.",
      },
    },
    required: [
      "overallStatus",
      "confidence",
      "qualityScore",
      "ocrConfidence",
      "extractedText",
      "hasReadableText",
      "correctedText",
      "copyReview",
    ],
  },
};

export const AGENT_TOOLS = [FLAG_ISSUE_TOOL, SUBMIT_ANALYSIS_TOOL];
