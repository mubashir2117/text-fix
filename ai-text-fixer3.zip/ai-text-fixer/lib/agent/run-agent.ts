import { AGENT_TOOLS } from "./tools";

const AGENT_SYSTEM_PROMPT = `You are the Text Fixer agent: an expert copy editor, grammar checker, and social media marketing copy reviewer, working through one image at a time.

You will be shown an image of a social media post, advertisement, banner, story design, or similar marketing graphic. Work through it step by step using your two tools:

1. Read ONLY the text that is visibly present in the image. Never invent, guess, or complete missing or unreadable text — if part of it is unclear, cut off, or too low-resolution, say so honestly rather than assuming what it says.
2. As you find each issue — spelling, grammar, punctuation, capitalization, wording, sentence structure, clarity, duplication, CTA weakness, or other copy problems — call flag_issue immediately for that one issue. Call it as many times as you have issues, one call per issue. Do not hold issues back to report later, and do not report the same issue twice.
3. Separate definite errors from optional stylistic preferences: give optional improvements "low" severity rather than omitting them or overstating them.
4. Once you've read the whole design and flagged every issue you found (or found none), write the full corrected version of the text. Preserve the original meaning, tone, and intent. Do NOT change brand names, product names, company names, URLs, phone numbers, prices, dates, hashtags, or industry-specific terminology unless they contain an obvious typo. Do not rewrite text that's already correct just to change its style.
5. Write a short, specific marketing-copy review: hook, clarity, value proposition, CTA, readability, conciseness, tone, and one overall sentence. Use real sentences, not single-word scores.
6. When you're confident in all of the above, call submit_analysis exactly once with the complete result. This ends your work.

If the image has no readable text at all, skip flag_issue entirely and call submit_analysis with hasReadableText set to false, extractedText and correctedText as empty strings, honest short copyReview fields (e.g. "No text was detected to review."), and an explanation in notes.

Always call submit_analysis before you finish — never end without it.`;

export interface AgentIssue {
  type: string;
  severity: string;
  original: string;
  correction: string;
  explanation: string;
}

export interface AgentResult {
  submission: Record<string, unknown>;
  issues: AgentIssue[];
  turns: number;
}

export class AgentRunError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = "AgentRunError";
  }
}

const MODEL = "claude-sonnet-5";
const MAX_TURNS = 12;

interface AnthropicContentBlock {
  type: string;
  [key: string]: unknown;
}

interface AnthropicMessage {
  role: "user" | "assistant";
  content: AnthropicContentBlock[];
}

async function callAnthropic(messages: AnthropicMessage[], apiKey: string) {
  let response: Response;
  try {
    response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 2048,
        system: AGENT_SYSTEM_PROMPT,
        tools: AGENT_TOOLS,
        messages,
      }),
    });
  } catch (err) {
    throw new AgentRunError("Could not reach the AI provider.", err);
  }

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new AgentRunError(`AI provider returned an error (${response.status}).`, text);
  }

  try {
    return await response.json();
  } catch (err) {
    throw new AgentRunError("The AI provider returned an unreadable response.", err);
  }
}

/**
 * Runs the Text Fixer agent loop against one image: repeatedly calls
 * Claude with the flag_issue / submit_analysis tools, executes each
 * tool call locally (flag_issue just records to an array; there is no
 * external side effect to run), and feeds the results back until the
 * agent calls submit_analysis or we hit MAX_TURNS.
 */
export async function runTextFixerAgent({
  base64Data,
  mimeType,
}: {
  base64Data: string;
  mimeType: string;
}): Promise<AgentResult> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new AgentRunError("The AI provider is not configured on the server.");
  }

  const issues: AgentIssue[] = [];
  let submission: Record<string, unknown> | null = null;

  const messages: AnthropicMessage[] = [
    {
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: mimeType, data: base64Data } },
        {
          type: "text",
          text: "Analyze the text in this image now. Use flag_issue for each issue you find, then finish with submit_analysis.",
        },
      ],
    },
  ];

  let turn = 0;
  while (turn < MAX_TURNS && !submission) {
    turn += 1;
    const data = await callAnthropic(messages, apiKey);

    const content: AnthropicContentBlock[] = data?.content ?? [];
    const toolUseBlocks = content.filter((block) => block.type === "tool_use");

    if (toolUseBlocks.length === 0) {
      // The agent stalled without calling a tool. Nudge it once instead
      // of failing immediately — models occasionally narrate before acting.
      messages.push({ role: "assistant", content });
      messages.push({
        role: "user",
        content: [
          {
            type: "text",
            text: "Please continue: call flag_issue for any remaining issues, then call submit_analysis to finish.",
          },
        ],
      });
      continue;
    }

    const toolResults: AnthropicContentBlock[] = [];

    for (const block of toolUseBlocks) {
      const name = block.name as string;
      const input = block.input as Record<string, unknown>;
      const toolUseId = block.id as string;

      if (name === "flag_issue") {
        issues.push({
          type: String(input.type ?? "other"),
          severity: String(input.severity ?? "low"),
          original: String(input.original ?? ""),
          correction: String(input.correction ?? ""),
          explanation: String(input.explanation ?? ""),
        });
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolUseId,
          content: "Recorded.",
        });
      } else if (name === "submit_analysis") {
        submission = input;
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolUseId,
          content: "Received. Analysis complete.",
        });
      } else {
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolUseId,
          content: "Unknown tool.",
          is_error: true,
        });
      }
    }

    messages.push({ role: "assistant", content });

    if (submission) break;

    messages.push({ role: "user", content: toolResults });
  }

  if (!submission) {
    throw new AgentRunError("The agent did not finish its analysis in time.");
  }

  return { submission, issues, turns: turn };
}
