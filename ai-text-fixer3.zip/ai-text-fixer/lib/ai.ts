import { AiAnalysisSchema, type AiAnalysis } from "./validation";
import { runTextFixerAgent, AgentRunError } from "./agent/run-agent";

export class AiAnalysisError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = "AiAnalysisError";
  }
}

interface AnalyzeImageInput {
  base64Data: string;
  mimeType: string;
}

/**
 * Finds things a well-behaved model should already have preserved
 * (prices, URLs, hashtags, standalone numbers) and flags — but never
 * silently "fixes" — anything the corrected text seems to have dropped.
 * This is a cheap code-side backstop alongside the instruction in the
 * agent's own system prompt; it never overrides the model, it only
 * adds a note the person can act on.
 */
function findDroppedEntities(original: string, corrected: string): string[] {
  const patterns = [
    /https?:\/\/\S+/gi,
    /\b[\w.-]+\.(?:com|io|co|net|org)\S*/gi,
    /#[\w]+/g,
    /\$\s?\d[\d,.]*/g,
    /\b\d[\d,]*\+?\b/g,
  ];

  const dropped = new Set<string>();
  for (const pattern of patterns) {
    const matches = original.match(pattern) ?? [];
    for (const match of matches) {
      if (!corrected.includes(match)) {
        dropped.add(match);
      }
    }
  }
  return Array.from(dropped);
}

/**
 * Runs the Text Fixer agent against one image and returns a validated
 * AiAnalysis object. Throws AiAnalysisError on any failure — callers
 * must not fabricate a result when this throws.
 */
export async function analyzeImageWithAi({ base64Data, mimeType }: AnalyzeImageInput): Promise<AiAnalysis> {
  let agentResult: Awaited<ReturnType<typeof runTextFixerAgent>>;
  try {
    agentResult = await runTextFixerAgent({ base64Data, mimeType });
  } catch (err) {
    if (err instanceof AgentRunError) {
      throw new AiAnalysisError(err.message, err.cause);
    }
    throw new AiAnalysisError("The agent failed to complete its analysis.", err);
  }

  const { submission, issues } = agentResult;

  const dropped =
    typeof submission.extractedText === "string" && typeof submission.correctedText === "string"
      ? findDroppedEntities(submission.extractedText, submission.correctedText)
      : [];

  const existingNotes = typeof submission.notes === "string" ? submission.notes : undefined;
  const droppedNote =
    dropped.length > 0
      ? `Double-check the corrected text: it may have dropped ${dropped.slice(0, 3).join(", ")}.`
      : undefined;
  const notes = [existingNotes, droppedNote].filter(Boolean).join(" ") || undefined;

  const candidate = {
    ...submission,
    issues,
    notes,
  };

  const result = AiAnalysisSchema.safeParse(candidate);
  if (!result.success) {
    throw new AiAnalysisError("The agent's response did not match the expected format.", result.error.flatten());
  }

  return result.data;
}
